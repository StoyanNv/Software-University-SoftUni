﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    public abstract class Configuration
    {
        public const string ConnectionString = "Server=DESKTOP-V3JOVJU\\SQLEXPRESS;Database=Hospital;Integrated Security=True";
    }
}
