﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace P01_HospitalDatabase
{
    public class Class1
    {
    }
}
