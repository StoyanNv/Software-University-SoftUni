﻿using System;
using P03_SalesDatabase.Data;

namespace P03_SalesDatabase
{
    class Program
    {
        static void Main()
        {
            using (var db = new SalesContext())
            {
                db.Database.EnsureCreated();
            }
        }
    }
}
