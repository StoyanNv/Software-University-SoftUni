﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
    public abstract class Configuration
    {
        public const string ConnectionString = "Server=DESKTOP-V3JOVJU\\SQLEXPRESS;Database=Sales;Integrated Security=True";
    }
}