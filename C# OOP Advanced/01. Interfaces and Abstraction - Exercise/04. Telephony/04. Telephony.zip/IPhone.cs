﻿public interface IPhone
{
    string call(string number);
    string browse(string site);
}